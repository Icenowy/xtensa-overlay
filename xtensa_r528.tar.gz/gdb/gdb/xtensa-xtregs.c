/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	240

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   43, 172,   8,   8,  4, -1, 0x0204, "br" },
  {   44, 176,   0,   0,  4, -1, 0x0210, "acclo" },
  {   45, 180,   4,   4,  4, -1, 0x0211, "acchi" },
  {   46, 184,  12,  12,  4, -1, 0x0220, "m0" },
  {   47, 188,  16,  16,  4, -1, 0x0221, "m1" },
  {   48, 192,  20,  20,  4, -1, 0x0222, "m2" },
  {   49, 196,  24,  24,  4, -1, 0x0223, "m3" },
  {   50, 200,   8,  40,  4,  1, 0x03f0, "ae_ovf_sar" },
  {   51, 204,  12,  44,  4,  1, 0x03f1, "ae_bithead" },
  {   52, 208,  16,  48,  4,  1, 0x03f2, "ae_ts_fts_bu_bp" },
  {   53, 212,  20,  52,  4,  1, 0x03f3, "ae_cw_sd_no" },
  {   54, 216,  24,  56,  4,  1, 0x03f6, "ae_cbegin0" },
  {   55, 220,  28,  60,  4,  1, 0x03f7, "ae_cend0" },
  {   56, 224,  32,  64,  4,  1, 0x03f8, "ae_cbegin1" },
  {   57, 228,  36,  68,  4,  1, 0x03f9, "ae_cend1" },
  {   58, 232,  40,  72,  8,  1, 0x1010, "aed0" },
  {   59, 240,  48,  80,  8,  1, 0x1011, "aed1" },
  {   60, 248,  56,  88,  8,  1, 0x1012, "aed2" },
  {   61, 256,  64,  96,  8,  1, 0x1013, "aed3" },
  {   62, 264,  72, 104,  8,  1, 0x1014, "aed4" },
  {   63, 272,  80, 112,  8,  1, 0x1015, "aed5" },
  {   64, 280,  88, 120,  8,  1, 0x1016, "aed6" },
  {   65, 288,  96, 128,  8,  1, 0x1017, "aed7" },
  {   66, 296, 104, 136,  8,  1, 0x1018, "aed8" },
  {   67, 304, 112, 144,  8,  1, 0x1019, "aed9" },
  {   68, 312, 120, 152,  8,  1, 0x101a, "aed10" },
  {   69, 320, 128, 160,  8,  1, 0x101b, "aed11" },
  {   70, 328, 136, 168,  8,  1, 0x101c, "aed12" },
  {   71, 336, 144, 176,  8,  1, 0x101d, "aed13" },
  {   72, 344, 152, 184,  8,  1, 0x101e, "aed14" },
  {   73, 352, 160, 192,  8,  1, 0x101f, "aed15" },
  {   74, 360, 176, 208,  8,  1, 0x1020, "u0" },
  {   75, 368, 184, 216,  8,  1, 0x1021, "u1" },
  {   76, 376, 192, 224,  8,  1, 0x1022, "u2" },
  {   77, 384, 200, 232,  8,  1, 0x1023, "u3" },
  {   78, 392, 168, 200,  1,  1, 0x1024, "aep0" },
  {   79, 393, 169, 201,  1,  1, 0x1025, "aep1" },
  {   80, 394, 170, 202,  1,  1, 0x1026, "aep2" },
  {   81, 395, 171, 203,  1,  1, 0x1027, "aep3" },
  {   82, 396,   0,  32,  4,  1, 0x1029, "fcr_fsr" },
  { 0 }
};

